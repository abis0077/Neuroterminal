# NeuroLink Terminal

Refer to `Neuroterminal Platform` document for setup and usage instructions.